package Controle;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

public  class ConectaBd {

    public Statement stm;
    public ResultSet rs;
    private String driver = "org.postgresql.Driver";
    private String caminho = "jdbc:postgresql://localhost:5432/Jlsistema";
    private String usuario = "postgres";
    private String senha = "=jean=";
    public Connection con;

    public void  Conexao() {
        try {
            System.setProperty("jdbc.Driver", driver);
            con = DriverManager.getConnection(caminho, usuario, senha);
            //JOptionPane.showMessageDialog(null, "Conectado com Sucesso");
        } catch (SQLException ex) {
           //JOptionPane.showMessageDialog(null, "Falha ao Conectar-se com o Banco" + ex.getMessage());
        }

    }

    public void ExecutaSql(String sql) {
        try {
            stm = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_READ_ONLY);
            rs = stm.executeQuery(sql);
        } catch (SQLException ex) {

            //JOptionPane.showMessageDialog(null," Erro ao executar Sql" +ex.getMessage());
        }

    }

    public void Desconecta() {
        try {
            con.close();
            //JOptionPane.showMessageDialog(null, "Desconectado com Sucesso");
        } catch (SQLException ex) {
           //JOptionPane.showMessageDialog(null, "Falha ao fechar o Banco de Dados" + ex.getMessage());
        }
    }

}
