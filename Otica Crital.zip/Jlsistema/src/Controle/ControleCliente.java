package Controle;

import Modelo.ModeloCliente;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class ControleCliente {

    ConectaBd conex = new ConectaBd();
    ModeloCliente mod = new ModeloCliente();

    public void Salvar(ModeloCliente mod) {
        conex.Conexao();
        try {
            PreparedStatement pst = conex.con.prepareStatement("insert into cliente(nome, numero, data)Values(?, ?, ?)");

            pst.setString(1, mod.getNome());
            pst.setString(2, mod.getNumero());
            pst.setString(3, mod.getData());
            pst.execute();

           // JOptionPane.showMessageDialog(null, "Cliente Inserido");

        } catch (SQLException ex) {
           // JOptionPane.showMessageDialog(null, "Erro ao inserir dados!/nError:" + ex);
        }
        conex.Desconecta();

    }

    public void Editar(ModeloCliente mod) {
        conex.Conexao();
        try {
            PreparedStatement pst = conex.con.prepareStatement("update cliente set nome = ?, numero = ?, data = ? where cod_cliente =? ");
            pst.setString(1, mod.getNome());
            pst.setString(2, mod.getNumero());
            pst.setString(3, mod.getData());
            pst.setInt(4, mod.getCodigo());
            pst.execute();
           // JOptionPane.showMessageDialog(null, "Dados alterados com sucesso!");
        }
        catch(SQLException exe){
        
            
        //JOptionPane.showMessageDialog(null, "Erro na alteraçao dos dados!n/Error:"+exe);
        
        
    }
        conex.Desconecta();
    }

    public void Excluir(ModeloCliente mod) {
        conex.Conexao();
        try {
            PreparedStatement pst = conex.con.prepareStatement("delete from cliente where cod_cliente = ?");
            pst.setInt(1, mod.getCodigo());
            pst.execute();
           // JOptionPane.showMessageDialog(null, "Cliente Excluido com sucesso");
        } catch (SQLException ex) {
          // JOptionPane.showMessageDialog(null, "Erro ao deletar Cliente!/nError:"+ex);
        }

        conex.Desconecta();
    }

    public ModeloCliente Pesquisar(ModeloCliente mod) {
        conex.Conexao();
        conex.ExecutaSql("select * from cliente where (nome) like'%" + mod.getPesquisa() + "%'");

        try {
            conex.rs.first();
            mod.setCodigo(conex.rs.getInt("cod_cliente"));
            mod.setNome(conex.rs.getString("nome"));
            mod.setNumero(conex.rs.getString("numero"));
            mod.setData(conex.rs.getString("data"));
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Letras Maiuscula na primeiras Letras do nome ou" +"\n"+
                    "Talvez o Cliente nao Possua Cadastro!");
        }
        conex.Desconecta();
        return mod;

    }

}
